<?php
 
namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\bannerimg;
 
class BannerController extends Controller
{
    public function show()
    {   
        // error_log('Passo');
        
        $data = bannerimg::all()->toJson();
        // $data=bannerimg::all();
        // $cs = implode(",", $data);
        // error_log($comma_separated);
        // return view('welcome', ['data' => $data]);
        // return response()->json($data, 204);
        #json_decode passa string json to json object
        return ['ok' => json_decode($data)];
    }
}