<?php
 
namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\product;
use App\Models\bannerimg;
use Illuminate\Http\Request;
 
class ProductController extends Controller
{
    public function show()
    {   
        // error_log('Passo');
        
        $data = product::all()->toJson();
        // $data=bannerimg::all();
        // $cs = implode(",", $data);
        // error_log($comma_separated);
        // return view('welcome', ['data' => $data]);
        // return response()->json($data, 204); 
        #json_decode passa string json to json object
        return ['ok' => json_decode($data)];
    }

    public function create(Request $request)
    {   
        // error_log('aaaaaaaaaa');
        try {            
            // product::create($request->only(['nome']));
            // $requestData = $request::all();
            // $requestData['atributo_computado'] = 'Qualquer valor';
            // product::create($requestData);
            $id_=product::count();
            $product = new product;
            $product->id = $id_+1;
            $product->nome = $request->nome;
            $product->desc = $request->desc;
            $product->preco = $request->preco;
            $product->status ='1';
            $product->imgs = explode("base64,",$request->img)[1];
            // $request->img;//
            // $product->owner = $request->owner; 
            $product->save(); 
        } catch (\Throwable $th) {
            error_log($th);
        }     
        // $data=bannerimg::all();
        // $cs = implode(",", $data);
        // error_log($comma_separated);
        // return view('welcome', ['data' => $data]);
        // return response()->json($data, 204);
        #json_decode passa string json to json object

        return ['ok' => ''];
    }
    public function update($id)
    {   
        $a=intval(product::findOrFail($id)->first()->status);
        $b=product::find($id);
        $a=strval($a+1);
        $b->status = $a;
        error_log($a);        
        try {
            $b->save();        
            //code...
        } catch (\Throwable $th) {
            error_log($th);
        }
        error_log('Passo 1');
        // update(['status' => $a+$a]);
        // $data=bannerimg::all();
        // $cs = implode(",", $data);
        // error_log($comma_separated);
        // return view('welcome', ['data' => $data]);
        // return response()->json($data, 204);
        #json_decode passa string json to json object
        return ['ok' => 'ok'];
    }
}