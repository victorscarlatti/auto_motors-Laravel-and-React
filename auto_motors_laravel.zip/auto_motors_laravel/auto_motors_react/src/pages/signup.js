import React from 'react';

const SignUp = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '90vh'
      }}
    >
      <h1>Sign Up</h1>
    </div>
  );
};

export default SignUp;
